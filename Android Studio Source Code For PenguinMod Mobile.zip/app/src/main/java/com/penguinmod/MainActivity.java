package com.penguinmod;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.*;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.penguinmod.databinding.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends AppCompatActivity {
	
	private MainBinding binding;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = MainBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		binding.webviewfor.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
	}
	
	private void initializeLogic() {
		final WebView webviewfor = (WebView) findViewById(R.id.webviewfor);
		
		// Enable Touch Focus, Context Menus & Selection
		webviewfor.setLongClickable(true);
		webviewfor.setFocusable(true);
		webviewfor.setFocusableInTouchMode(true);
		webviewfor.setHapticFeedbackEnabled(true);
		
		// 1. Request Runtime Permissions
		if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
			if (checkSelfPermission(android.Manifest.permission.CAMERA) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
				requestPermissions(new String[]{android.Manifest.permission.CAMERA}, 2001);
			}
		}
		
		if (android.os.Build.VERSION.SDK_INT >= 33) {
			if (checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
				requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 2003);
			}
		}
		
		if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
			if (!android.os.Environment.isExternalStorageManager()) {
				new android.app.AlertDialog.Builder(this)
				.setTitle("Permission Required")
				.setMessage("This app needs 'All Files Access' to open, edit, and overwrite your project files directly.")
				.setCancelable(false)
				.setPositiveButton("Grant Access", new android.content.DialogInterface.OnClickListener() {
					@Override
					public void onClick(android.content.DialogInterface dialog, int which) {
						try {
							android.content.Intent intent = new android.content.Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
							android.net.Uri uri = android.net.Uri.fromParts("package", getPackageName(), null);
							intent.setData(uri);
							startActivity(intent);
						} catch (Exception e) {
							android.content.Intent intent = new android.content.Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
							startActivity(intent);
						}
					}
				})
				.setNegativeButton("Cancel", null)
				.show();
			}
		}
		
		// 2. Storage, Cookies & Web Settings Persistence
		webviewfor.getSettings().setJavaScriptEnabled(true);
		webviewfor.getSettings().setDomStorageEnabled(true);
		webviewfor.getSettings().setDatabaseEnabled(true);
		webviewfor.getSettings().setMediaPlaybackRequiresUserGesture(false);
		
		String dbPath = getApplicationContext().getFilesDir().getPath() + "/webviews/databases";
		webviewfor.getSettings().setDatabasePath(dbPath);
		
		webviewfor.getSettings().setAllowFileAccess(true);
		webviewfor.getSettings().setAllowContentAccess(true);
		
		// Enable Hardware Acceleration & Mixed Content
		webviewfor.setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null);
		if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
			webviewfor.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
		}
		
		// Enable Cookie Persistence
		android.webkit.CookieManager cookieManager = android.webkit.CookieManager.getInstance();
		cookieManager.setAcceptCookie(true);
		if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
			cookieManager.setAcceptThirdPartyCookies(webviewfor, true);
		}
		
		// Enable Popups
		webviewfor.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
		webviewfor.getSettings().setSupportMultipleWindows(true);
		
		// 3. Cache Settings & Screen Scale Fix (70% Native Scale for < 500dp)
		android.net.ConnectivityManager cm = (android.net.ConnectivityManager) getSystemService(android.content.Context.CONNECTIVITY_SERVICE);
		android.net.NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
		boolean isOnline = (activeNetwork != null && activeNetwork.isConnectedOrConnecting());
		
		if (isOnline) {
			webviewfor.getSettings().setCacheMode(android.webkit.WebSettings.LOAD_DEFAULT);
		} else {
			webviewfor.getSettings().setCacheMode(android.webkit.WebSettings.LOAD_CACHE_ELSE_NETWORK);
		}
		
		int smallestWidthDp = getResources().getConfiguration().smallestScreenWidthDp;
		if (smallestWidthDp < 500) {
			webviewfor.setInitialScale(65);
		} else {
			webviewfor.setInitialScale(90);
		}
		
		webviewfor.getSettings().setSupportZoom(false);
		webviewfor.getSettings().setBuiltInZoomControls(false);
		webviewfor.getSettings().setDisplayZoomControls(false);
		webviewfor.getSettings().setUseWideViewPort(true);
		webviewfor.getSettings().setLoadWithOverviewMode(true);
		
		// 4. Create Notification Channel (Android 8.0+)
		final String NOTIF_CHANNEL_ID = "web_project_notifications";
		if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
			android.app.NotificationChannel channel = new android.app.NotificationChannel(
			NOTIF_CHANNEL_ID,
			"Project Notifications",
			android.app.NotificationManager.IMPORTANCE_HIGH
			);
			channel.setDescription("Notifications sent from loaded projects");
			channel.enableVibration(true);
			android.app.NotificationManager manager = (android.app.NotificationManager) getSystemService(android.content.Context.NOTIFICATION_SERVICE);
			if (manager != null) {
				manager.createNotificationChannel(channel);
			}
		}
		
		// 5. Native Javascript Bridge Object with Full Synchronous Clipboard Copy/Paste
		final Object androidHostInterface = new Object() {
			
			@android.webkit.JavascriptInterface
			public void copyToClipboard(final String text) {
				runOnUiThread(new Runnable() {
					public void run() {
						try {
							android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(android.content.Context.CLIPBOARD_SERVICE);
							android.content.ClipData clip = android.content.ClipData.newPlainText("Copied Text", text);
							if (clipboard != null) {
								clipboard.setPrimaryClip(clip);
								android.widget.Toast.makeText(getApplicationContext(), "Copied to clipboard!", android.widget.Toast.LENGTH_SHORT).show();
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}
			
			@android.webkit.JavascriptInterface
			public String readFromClipboard() {
				final java.util.concurrent.atomic.AtomicReference<String> result = new java.util.concurrent.atomic.AtomicReference<>("");
				final java.util.concurrent.CountDownLatch latch = new java.util.concurrent.CountDownLatch(1);
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						try {
							android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(android.content.Context.CLIPBOARD_SERVICE);
							if (clipboard != null && clipboard.hasPrimaryClip()) {
								android.content.ClipData clip = clipboard.getPrimaryClip();
								if (clip != null && clip.getItemCount() > 0) {
									CharSequence text = clip.getItemAt(0).coerceToText(getApplicationContext());
									if (text != null) {
										result.set(text.toString());
									}
								}
							}
						} catch (Exception e) {
							e.printStackTrace();
						} finally {
							latch.countDown();
						}
					}
				});
				try {
					latch.await(1, java.util.concurrent.TimeUnit.SECONDS);
				} catch (Exception e) {}
				return result.get();
			}
			
			@android.webkit.JavascriptInterface
			public void sendNotification(final String title, final String body, final String iconUrl) {
				runOnUiThread(new Runnable() {
					public void run() {
						try {
							android.app.NotificationManager notificationManager = 
							(android.app.NotificationManager) getSystemService(android.content.Context.NOTIFICATION_SERVICE);
							if (notificationManager == null) return;
							
							android.app.Notification.Builder builder;
							if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
								builder = new android.app.Notification.Builder(getApplicationContext(), NOTIF_CHANNEL_ID);
							} else {
								builder = new android.app.Notification.Builder(getApplicationContext());
							}
							
							builder.setContentTitle(title)
							.setContentText(body)
							.setSmallIcon(android.R.drawable.ic_dialog_info)
							.setPriority(android.app.Notification.PRIORITY_HIGH)
							.setAutoCancel(true);
							
							notificationManager.notify((int) System.currentTimeMillis(), builder.build());
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}
			
			@android.webkit.JavascriptInterface
			public void requestOpenFile(final String reqId) {
				runOnUiThread(new Runnable() {
					public void run() {
						webviewfor.setTag(R.id.webviewfor + 200, reqId);
						android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT);
						intent.addCategory(android.content.Intent.CATEGORY_OPENABLE);
						intent.setType("*/*");
						intent.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION | android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION | android.content.Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
						((android.app.Activity) webviewfor.getContext()).startActivityForResult(intent, 3001);
					}
				});
			}
			
			@android.webkit.JavascriptInterface
			public void requestSaveFile(final String reqId, final String suggestedName) {
				runOnUiThread(new Runnable() {
					public void run() {
						webviewfor.setTag(R.id.webviewfor + 200, reqId);
						android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT);
						intent.addCategory(android.content.Intent.CATEGORY_OPENABLE);
						intent.setType("*/*"); 
						intent.putExtra(android.content.Intent.EXTRA_TITLE, suggestedName);
						intent.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION | android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION | android.content.Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
						((android.app.Activity) webviewfor.getContext()).startActivityForResult(intent, 3002);
					}
				});
			}
			
			@android.webkit.JavascriptInterface
			public void overwriteFile(final String uriString, final String base64Data) {
				runOnUiThread(new Runnable() {
					public void run() {
						try {
							android.net.Uri uri = android.net.Uri.parse(uriString);
							String pureBase64 = base64Data.contains(",") ? base64Data.substring(base64Data.indexOf(",") + 1) : base64Data;
							byte[] fileData = android.util.Base64.decode(pureBase64, android.util.Base64.DEFAULT);
							java.io.OutputStream os = getContentResolver().openOutputStream(uri, "rwt");
							if (os != null) {
								os.write(fileData);
								os.flush();
								os.close();
								android.widget.Toast.makeText(getApplicationContext(), "File Saved Successfully!", android.widget.Toast.LENGTH_SHORT).show();
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}
		};
		
		// 6. Complete JavaScript Polyfill Script (Fixes Copy, Paste, and Text Selection)
		final String CLIPBOARD_AND_NOTIF_JS = "javascript:(function() {" +
		"  if (!window.__cbInjected) {" +
		"    window.__cbInjected = true;" +
		"    var customClipboard = {" +
		"      writeText: function(text) {" +
		"        if (window.AndroidHost && window.AndroidHost.copyToClipboard) {" +
		"          window.AndroidHost.copyToClipboard(String(text));" +
		"        }" +
		"        return Promise.resolve();" +
		"      }," +
		"      readText: function() {" +
		"        if (window.AndroidHost && window.AndroidHost.readFromClipboard) {" +
		"          var t = window.AndroidHost.readFromClipboard();" +
		"          return Promise.resolve(t || '');" +
		"        }" +
		"        return Promise.resolve('');" +
		"      }," +
		"      write: function() { return Promise.resolve(); }," +
		"      read: function() { return Promise.resolve([]); }" +
		"    };" +
		"    try {" +
		"      Object.defineProperty(navigator, 'clipboard', {" +
		"        value: customClipboard, writable: true, configurable: true" +
		"      });" +
		"    } catch(e) { navigator.clipboard = customClipboard; }" +
		"    var origExec = document.execCommand;" +
		"    document.execCommand = function(cmd, showUI, val) {" +
		"      if (String(cmd).toLowerCase() === 'copy') {" +
		"        var selText = window.getSelection() ? window.getSelection().toString() : '';" +
		"        if (selText && window.AndroidHost && window.AndroidHost.copyToClipboard) {" +
		"          window.AndroidHost.copyToClipboard(selText);" +
		"          return true;" +
		"        }" +
		"      }" +
		"      try { return origExec.apply(document, arguments); } catch(e) { return false; }" +
		"    };" +
		"  }" +
		"  if (!window.__notifInjected) {" +
		"    window.__notifInjected = true;" +
		"    function NativeNotification(title, options) {" +
		"      options = options || {};" +
		"      if (window.AndroidHost && window.AndroidHost.sendNotification) {" +
		"        window.AndroidHost.sendNotification(title, options.body || '', options.icon || '');" +
		"      }" +
		"      this.title = title;" +
		"      this.body = options.body || '';" +
		"      this.close = function() {};" +
		"    }" +
		"    NativeNotification.permission = 'granted';" +
		"    NativeNotification.requestPermission = function(cb) {" +
		"      var p = Promise.resolve('granted');" +
		"      if (typeof cb === 'function') { p.then(cb); }" +
		"      return p;" +
		"    };" +
		"    window.Notification = NativeNotification;" +
		"    if (navigator.permissions && navigator.permissions.query) {" +
		"      var origQuery = navigator.permissions.query.bind(navigator.permissions);" +
		"      navigator.permissions.query = function(param) {" +
		"        if (param && param.name === 'notifications') {" +
		"          return Promise.resolve({ state: 'granted', onchange: null });" +
		"        }" +
		"        return origQuery(param);" +
		"      };" +
		"    }" +
		"  }" +
		"})()";
		
		// 7. WebView Navigation, Anti-Block & Polyfill Injection
		webviewfor.setWebViewClient(new android.webkit.WebViewClient() {
			@Override
			public void onPageStarted(android.webkit.WebView view, String url, android.graphics.Bitmap favicon) {
				super.onPageStarted(view, url, favicon);
				view.loadUrl(CLIPBOARD_AND_NOTIF_JS);
			}
			
			@Override
			public boolean shouldOverrideUrlLoading(android.webkit.WebView view, android.webkit.WebResourceRequest request) {
				if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
					if (!request.isForMainFrame()) {
						return false;
					}
				}
				String url = request.getUrl().toString();
				return handleExternalNavigation(view, url);
			}
			
			@SuppressWarnings("deprecation")
			@Override
			public boolean shouldOverrideUrlLoading(android.webkit.WebView view, String url) {
				return handleExternalNavigation(view, url);
			}
			
			private boolean handleExternalNavigation(android.webkit.WebView view, String url) {
				if (url == null) return false;
				
				boolean isGoogleAuth = url.contains("accounts.google.com") || url.contains("google.com/accounts");
				
				if (isGoogleAuth) {
					android.content.Context ctx = view.getContext();
					try {
						android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url));
						intent.setPackage("com.android.chrome");
						
						android.os.Bundle extras = new android.os.Bundle();
						if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN_MR2) {
							extras.putBinder("android.support.customtabs.extra.SESSION", (android.os.IBinder) null);
						}
						intent.putExtras(extras);
						intent.putExtra("android.support.customtabs.extra.TITLE_VISIBILITY", 1);
						
						ctx.startActivity(intent);
					} catch (Exception e) {
						try {
							android.content.Intent fallback = new android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url));
							ctx.startActivity(fallback);
						} catch (Exception ex) {}
					}
					return true;
				}
				
				return false;
			}
			
			// Only proxy HTML documents to preserve WebGL textures, audio, sprites & images
			@Override
			public android.webkit.WebResourceResponse shouldInterceptRequest(android.webkit.WebView view, android.webkit.WebResourceRequest request) {
				if (request != null && request.getUrl() != null && !request.isForMainFrame()) {
					String url = request.getUrl().toString();
					java.util.Map<String, String> reqHeaders = request.getRequestHeaders();
					String acceptHeader = (reqHeaders != null && reqHeaders.containsKey("Accept")) ? reqHeaders.get("Accept") : "";
					
					boolean isHtmlRequest = acceptHeader != null && acceptHeader.contains("text/html");
					
					if (isHtmlRequest && (url.startsWith("http://") || url.startsWith("https://"))) {
						try {
							java.net.URL urlObj = new java.net.URL(url);
							java.net.HttpURLConnection conn = (java.net.HttpURLConnection) urlObj.openConnection();
							conn.setRequestMethod(request.getMethod());
							
							if (reqHeaders != null) {
								for (java.util.Map.Entry<String, String> entry : reqHeaders.entrySet()) {
									conn.setRequestProperty(entry.getKey(), entry.getValue());
								}
							}
							conn.connect();
							
							String contentType = conn.getContentType();
							String mimeType = "text/html";
							
							if (contentType != null) {
								if (contentType.contains(";")) {
									mimeType = contentType.split(";")[0].trim();
								} else {
									mimeType = contentType.trim();
								}
							}
							
							java.util.Map<String, String> headers = new java.util.HashMap<>();
							for (java.util.Map.Entry<String, java.util.List<String>> entry : conn.getHeaderFields().entrySet()) {
								if (entry.getKey() != null) {
									String key = entry.getKey().toLowerCase();
									if (!key.equals("x-frame-options") && !key.equals("content-security-policy") && !key.equals("frame-ancestors")) {
										headers.put(entry.getKey(), entry.getValue().get(0));
									}
								}
							}
							headers.put("Access-Control-Allow-Origin", "*");
							
							return new android.webkit.WebResourceResponse(
							mimeType, conn.getContentEncoding(), conn.getResponseCode(), conn.getResponseMessage(), headers, conn.getInputStream()
							);
						} catch (Exception e) {}
					}
				}
				return super.shouldInterceptRequest(view, request);
			}
			
			@Override
			public void onPageFinished(android.webkit.WebView view, String url) {
				super.onPageFinished(view, url);
				
				if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
					android.webkit.CookieManager.getInstance().flush();
				}
				
				// Re-inject polyfills
				view.loadUrl(CLIPBOARD_AND_NOTIF_JS);
				
				int swDp = view.getContext().getResources().getConfiguration().smallestScreenWidthDp;
				String viewportScaleJs = (swDp < 500) ?
				"var meta = document.querySelector('meta[name=\"viewport\"]');" +
				"if (!meta) { meta = document.createElement('meta'); meta.name = 'viewport'; document.head.appendChild(meta); }" +
				"meta.content = 'width=device-width, initial-scale=0.7, maximum-scale=1.0, user-scalable=no';" : "";
				
				String selectionCssJs = "javascript:(function() {" +
				viewportScaleJs +
				"  var style = document.createElement('style');" +
				"  style.innerHTML = 'input, textarea, [contenteditable=\"true\"], code, pre, .selectable, span, p { -webkit-user-select: text !important; user-select: text !important; -webkit-touch-callout: default !important; }';" +
				"  document.head.appendChild(style);" +
				"})()";
				view.loadUrl(selectionCssJs);
				
				String fsaPolyfillJs = "javascript:(function() {" +
				"  if (window.__fsaInjected) return;" +
				"  window.__fsaInjected = true;" +
				"  window.__pendingPromises = {};" +
				
				"  window.__createMockWritable = function(uriString) {" +
				"    var chunks = [];" +
				"    return {" +
				"      write: async function(data) { chunks.push(data); }," +
				"      close: async function() {" +
				"        var blob = new Blob(chunks);" +
				"        var reader = new FileReader();" +
				"        reader.readAsDataURL(blob);" +
				"        reader.onloadend = function() {" +
				"          if (window.AndroidHost && window.AndroidHost.overwriteFile) {" +
				"            window.AndroidHost.overwriteFile(uriString, reader.result);" +
				"          }" +
				"        };" +
				"      }" +
				"    };" +
				"  };" +
				
				"  window.showOpenFilePicker = async function(options) {" +
				"    return new Promise(function(resolve, reject) {" +
				"      var id = 'req_' + Date.now() + '_' + Math.random();" +
				"      window.__pendingPromises[id] = { resolve: resolve, reject: reject };" +
				"      window.AndroidHost.requestOpenFile(id);" +
				"    });" +
				"  };" +
				
				"  window.showSaveFilePicker = async function(options) {" +
				"    var suggestedName = (options && options.suggestedName) ? options.suggestedName : 'project.pmp';" +
				"    return new Promise(function(resolve, reject) {" +
				"      var id = 'req_' + Date.now() + '_' + Math.random();" +
				"      window.__pendingPromises[id] = { resolve: resolve, reject: reject };" +
				"      window.AndroidHost.requestSaveFile(id, suggestedName);" +
				"    });" +
				"  };" +
				
				"  window.__onFileOpened = function(reqId, uriString, fileName, base64Content) {" +
				"    var promise = window.__pendingPromises[reqId];" +
				"    if (!promise) return;" +
				"    delete window.__pendingPromises[reqId];" +
				"    var byteChars = atob(base64Content);" +
				"    var byteNums = new Array(byteChars.length);" +
				"    for (var i = 0; i < byteChars.length; i++) { byteNums[i] = byteChars.charCodeAt(i); }" +
				"    var blob = new Blob([new Uint8Array(byteNums)], { type: 'application/octet-stream' });" +
				"    var fileObj = new File([blob], fileName, { lastModified: Date.now() });" +
				"    var handle = {" +
				"      kind: 'file'," +
				"      name: fileName," +
				"      getFile: async function() { return fileObj; }," +
				"      createWritable: async function() { return window.__createMockWritable(uriString); }" +
				"    };" +
				"    promise.resolve([handle]);" +
				"  };" +
				
				"  window.__onFileSaveCreated = function(reqId, uriString, fileName) {" +
				"    var promise = window.__pendingPromises[reqId];" +
				"    if (!promise) return;" +
				"    delete window.__pendingPromises[reqId];" +
				"    var handle = {" +
				"      kind: 'file'," +
				"      name: fileName," +
				"      getFile: async function() { return new File([], fileName); }," +
				"      createWritable: async function() { return window.__createMockWritable(uriString); }" +
				"    };" +
				"    promise.resolve(handle);" +
				"  };" +
				
				"  window.__onFileCancel = function(reqId) {" +
				"    var promise = window.__pendingPromises[reqId];" +
				"    if (!promise) return;" +
				"    delete window.__pendingPromises[reqId];" +
				"    promise.reject(new DOMException('User cancelled', 'AbortError'));" +
				"  };" +
				"})()";
				webviewfor.loadUrl(fsaPolyfillJs);
			}
		});
		
		// 8. Chrome Client Settings
		webviewfor.setWebChromeClient(new android.webkit.WebChromeClient() {
			@Override
			public void onPermissionRequest(final android.webkit.PermissionRequest request) {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						request.grant(request.getResources());
					}
				});
			}
			
			@Override
			public boolean onShowFileChooser(android.webkit.WebView webView, android.webkit.ValueCallback<android.net.Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
				android.webkit.ValueCallback<android.net.Uri[]> oldCb = (android.webkit.ValueCallback<android.net.Uri[]>) webView.getTag(R.id.webviewfor + 100);
				if (oldCb != null) {
					try { oldCb.onReceiveValue(null); } catch (Exception e) {}
				}
				webView.setTag(R.id.webviewfor + 100, filePathCallback);
				
				try {
					android.content.Intent openIntent = new android.content.Intent(android.content.Intent.ACTION_GET_CONTENT);
					openIntent.addCategory(android.content.Intent.CATEGORY_OPENABLE);
					openIntent.setType("*/*");
					
					((android.app.Activity) webView.getContext()).startActivityForResult(
					android.content.Intent.createChooser(openIntent, "Select File"), 1001
					);
				} catch (Exception e) {
					if (filePathCallback != null) filePathCallback.onReceiveValue(null);
					webView.setTag(R.id.webviewfor + 100, null);
					return false;
				}
				return true;
			}
			
			@Override
			public boolean onCreateWindow(android.webkit.WebView view, boolean isDialog, boolean isUserGesture, android.os.Message resultMsg) {
				final android.webkit.WebView popWebView = new android.webkit.WebView(view.getContext());
				popWebView.getSettings().setJavaScriptEnabled(true);
				popWebView.getSettings().setDomStorageEnabled(true);
				popWebView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
				popWebView.getSettings().setMediaPlaybackRequiresUserGesture(false);
				popWebView.setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null);
				
				popWebView.setLongClickable(true);
				popWebView.setFocusable(true);
				popWebView.setFocusableInTouchMode(true);
				popWebView.setHapticFeedbackEnabled(true);
				
				popWebView.addJavascriptInterface(androidHostInterface, "AndroidHost");
				
				if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
					android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(popWebView, true);
				}
				
				final android.app.Dialog popupDialog = new android.app.Dialog(view.getContext(), android.R.style.Theme_Black_NoTitleBar_Fullscreen);
				
				if (popupDialog.getWindow() != null) {
					popupDialog.getWindow().getAttributes().windowAnimations = android.R.style.Animation_Dialog;
				}
				
				final android.widget.FrameLayout container = new android.widget.FrameLayout(view.getContext());
				container.addView(popWebView, new android.widget.FrameLayout.LayoutParams(
				android.widget.FrameLayout.LayoutParams.MATCH_PARENT, 
				android.widget.FrameLayout.LayoutParams.MATCH_PARENT
				));
				
				android.widget.TextView closeButton = new android.widget.TextView(view.getContext());
				closeButton.setText("✕");
				closeButton.setTextSize(18);
				closeButton.setTextColor(android.graphics.Color.WHITE);
				closeButton.setGravity(android.view.Gravity.CENTER);
				
				android.graphics.drawable.GradientDrawable circleBg = new android.graphics.drawable.GradientDrawable();
				circleBg.setShape(android.graphics.drawable.GradientDrawable.OVAL);
				circleBg.setColor(android.graphics.Color.parseColor("#CC000000"));
				circleBg.setStroke(3, android.graphics.Color.parseColor("#55FFFFFF"));
				closeButton.setBackground(circleBg);
				
				float density = view.getContext().getResources().getDisplayMetrics().density;
				int buttonSize = (int) (48 * density);
				
				android.widget.FrameLayout.LayoutParams btnParams = new android.widget.FrameLayout.LayoutParams(buttonSize, buttonSize);
				btnParams.gravity = android.view.Gravity.TOP | android.view.Gravity.START;
				
				int margin = (int) (16 * density);
				btnParams.setMargins(margin, margin, 0, 0);
				closeButton.setLayoutParams(btnParams);
				
				final Runnable dismissWithAnimation = new Runnable() {
					@Override
					public void run() {
						container.animate()
						.alpha(0.0f)
						.scaleX(0.85f)
						.scaleY(0.85f)
						.setDuration(200)
						.setInterpolator(new android.view.animation.DecelerateInterpolator())
						.setListener(new android.animation.AnimatorListenerAdapter() {
							@Override
							public void onAnimationEnd(android.animation.Animator animation) {
								try {
									popupDialog.dismiss();
									popWebView.destroy();
								} catch (Exception e) {}
							}
						})
						.start();
					}
				};
				
				closeButton.setOnClickListener(new android.view.View.OnClickListener() {
					@Override
					public void onClick(android.view.View v) {
						dismissWithAnimation.run();
					}
				});
				
				container.addView(closeButton);
				popupDialog.setContentView(container);
				
				container.setAlpha(0.0f);
				container.setScaleX(0.85f);
				container.setScaleY(0.85f);
				
				popupDialog.show();
				
				container.animate()
				.alpha(1.0f)
				.scaleX(1.0f)
				.scaleY(1.0f)
				.setDuration(250)
				.setInterpolator(new android.view.animation.DecelerateInterpolator())
				.start();
				
				popWebView.setWebChromeClient(new android.webkit.WebChromeClient() {
					@Override
					public void onPermissionRequest(final android.webkit.PermissionRequest request) {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								request.grant(request.getResources());
							}
						});
					}
					
					@Override
					public void onCloseWindow(android.webkit.WebView window) {
						dismissWithAnimation.run();
					}
				});
				
				popWebView.setWebViewClient(new android.webkit.WebViewClient() {
					@Override
					public void onPageStarted(android.webkit.WebView view, String url, android.graphics.Bitmap favicon) {
						super.onPageStarted(view, url, favicon);
						view.loadUrl(CLIPBOARD_AND_NOTIF_JS);
					}
					
					@Override
					public boolean shouldOverrideUrlLoading(android.webkit.WebView view, android.webkit.WebResourceRequest request) {
						if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
							if (!request.isForMainFrame()) {
								return false;
							}
						}
						String url = request.getUrl().toString();
						
						if (url != null && (url.contains("accounts.google.com") || url.contains("google.com/accounts"))) {
							try {
								android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url));
								intent.setPackage("com.android.chrome");
								
								android.os.Bundle extras = new android.os.Bundle();
								if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN_MR2) {
									extras.putBinder("android.support.customtabs.extra.SESSION", (android.os.IBinder) null);
								}
								intent.putExtras(extras);
								view.getContext().startActivity(intent);
							} catch (Exception e) {
								try {
									android.content.Intent fallback = new android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url));
									view.getContext().startActivity(fallback);
								} catch (Exception ex) {}
							}
							return true;
						}
						return false;
					}
					
					@Override
					public void onPageFinished(android.webkit.WebView view, String url) {
						super.onPageFinished(view, url);
						view.loadUrl(CLIPBOARD_AND_NOTIF_JS);
					}
				});
				
				android.webkit.WebView.WebViewTransport transport = (android.webkit.WebView.WebViewTransport) resultMsg.obj;
				transport.setWebView(popWebView);
				resultMsg.sendToTarget();
				return true;
			}
		});
		
		// 9. Attach Bridge & Load Editor
		webviewfor.addJavascriptInterface(androidHostInterface, "AndroidHost");
		webviewfor.loadUrl("https://studio.penguinmod.com/editor.html");
		
		binding.webviewfor.loadUrl("https://studio.penguinmod.com/editor.html");
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		WebView webviewfor = (WebView) findViewById(R.id.webviewfor);
		
		// 1. Standard HTML File Input Request
		if (_requestCode == 1001) {
			android.webkit.ValueCallback<android.net.Uri[]> uploadMsg = (android.webkit.ValueCallback<android.net.Uri[]>) webviewfor.getTag(R.id.webviewfor + 100);
			if (uploadMsg != null) {
				android.net.Uri[] results = null;
				if (_resultCode == RESULT_OK && _data != null) {
					String dataString = _data.getDataString();
					if (dataString != null) {
						results = new android.net.Uri[]{ android.net.Uri.parse(dataString) };
					} else if (_data.getClipData() != null && _data.getClipData().getItemCount() > 0) {
						results = new android.net.Uri[]{ _data.getClipData().getItemAt(0).getUri() };
					}
				}
				uploadMsg.onReceiveValue(results);
				webviewfor.setTag(R.id.webviewfor + 100, null);
			}
		}
		
		// 2. Open Document Request (File System Access - Load)
		if (_requestCode == 3001) {
			String reqId = (String) webviewfor.getTag(R.id.webviewfor + 200);
			if (reqId != null) {
				if (_resultCode == RESULT_OK && _data != null && _data.getData() != null) {
					android.net.Uri uri = _data.getData();
					try {
						int takeFlags = _data.getFlags() & (android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION | android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
						try { getContentResolver().takePersistableUriPermission(uri, takeFlags); } catch (Exception e) {}
						
						String fileName = "project.pmp";
						android.database.Cursor cursor = getContentResolver().query(uri, null, null, null, null);
						if (cursor != null && cursor.moveToFirst()) {
							int nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
							if (nameIndex != -1) fileName = cursor.getString(nameIndex);
							cursor.close();
						}
						
						java.io.InputStream is = getContentResolver().openInputStream(uri);
						java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
						byte[] data = new byte[16384];
						int nRead;
						while ((nRead = is.read(data, 0, data.length)) != -1) {
							buffer.write(data, 0, nRead);
						}
						buffer.flush();
						byte[] bytes = buffer.toByteArray();
						is.close();
						
						String base64 = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP);
						String safeUri = uri.toString().replace("'", "\\'");
						String safeName = fileName.replace("'", "\\'");
						
						String js = "window.__onFileOpened('" + reqId + "', '" + safeUri + "', '" + safeName + "', '" + base64 + "');";
						webviewfor.evaluateJavascript(js, null);
					} catch (Exception e) {
						e.printStackTrace();
						webviewfor.evaluateJavascript("window.__onFileCancel('" + reqId + "');", null);
					}
				} else {
					webviewfor.evaluateJavascript("window.__onFileCancel('" + reqId + "');", null);
				}
				webviewfor.setTag(R.id.webviewfor + 200, null);
			}
		}
		
		// 3. Create Document Request (File System Access - Initial Save As)
		if (_requestCode == 3002) {
			String reqId = (String) webviewfor.getTag(R.id.webviewfor + 200);
			if (reqId != null) {
				if (_resultCode == RESULT_OK && _data != null && _data.getData() != null) {
					android.net.Uri uri = _data.getData();
					try {
						int takeFlags = _data.getFlags() & (android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION | android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
						try { getContentResolver().takePersistableUriPermission(uri, takeFlags); } catch (Exception e) {}
						
						String fileName = "project.pmp";
						android.database.Cursor cursor = getContentResolver().query(uri, null, null, null, null);
						if (cursor != null && cursor.moveToFirst()) {
							int nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
							if (nameIndex != -1) fileName = cursor.getString(nameIndex);
							cursor.close();
						}
						
						String safeUri = uri.toString().replace("'", "\\'");
						String safeName = fileName.replace("'", "\\'");
						
						String js = "window.__onFileSaveCreated('" + reqId + "', '" + safeUri + "', '" + safeName + "');";
						webviewfor.evaluateJavascript(js, null);
					} catch (Exception e) {
						e.printStackTrace();
						webviewfor.evaluateJavascript("window.__onFileCancel('" + reqId + "');", null);
					}
				} else {
					webviewfor.evaluateJavascript("window.__onFileCancel('" + reqId + "');", null);
				}
				webviewfor.setTag(R.id.webviewfor + 200, null);
			}
		}
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		WebView webviewfor = (WebView) findViewById(R.id.webviewfor);
		
		if (webviewfor.canGoBack()) {
			webviewfor.goBack();
		} else {
			finish();
		}
		
	}
}